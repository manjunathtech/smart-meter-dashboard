# Smart Energy Dashboard - Backend with Auth (Node.js + Express + MongoDB)
