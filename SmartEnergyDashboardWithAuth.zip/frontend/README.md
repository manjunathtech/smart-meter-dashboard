# Smart Energy Dashboard - Frontend with Login/Signup
